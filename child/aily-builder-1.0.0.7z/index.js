#!/usr/bin/env node
// Auto-generated launch script for aily-builder
const path = require('path');

// 设置模块查找路径，确保能找到原生模块
const originalResolveFilename = require.extensions['.node'] || require._extensions['.node'];
const bundleDir = __dirname;
const nodeModulesPath = path.join(bundleDir, 'node_modules');

// 添加 bundle 目录的 node_modules 到模块查找路径
if (!module.paths.includes(nodeModulesPath)) {
  module.paths.unshift(nodeModulesPath);
}

// 启动主程序
require('./aily-builder.js');
