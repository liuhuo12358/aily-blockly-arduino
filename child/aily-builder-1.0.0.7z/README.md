# Aily Builder Complete Bundle

This is a complete bundle of aily-builder including all native dependencies.

## Usage

```bash
# Run directly
node index.js [command] [options]

# Or if you have the bundle in PATH
aily [command] [options]
```

## Examples

```bash
# Show help
node index.js --help

# Compile Arduino sketch
node index.js compile examples/blink.ino --verbose

# Show version
node index.js --version
```

## Files included

- `index.js` - Launch script
- `aily-builder.js` - Main bundled application
- `node_modules/tree-sitter/` - Tree-sitter parser with native bindings
- `node_modules/tree-sitter-cpp/` - C++ language grammar for tree-sitter
- `node_modules/tree-sitter-c/` - C language grammar (dependency of tree-sitter-cpp)
- `node_modules/node-gyp-build/` - Native module loader
- `node_modules/node-addon-api/` - Node.js addon API

## System Requirements

- Node.js >= 16
- The native modules are compiled for win32-x64
